export const ActionTypes = {
    SET_USER: 'SET_USER'
}