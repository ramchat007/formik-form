import { createSlice } from "@reduxjs/toolkit";

const roleSlice = createSlice({
    name: "role",
    initialState: [],
    reducers: {
        newRole(state, action) {
            state.push(action.payload);
        },
        fetchRole(state, action) {
            return action.payload
        },
        existingRole(state, action) {
            state = action.payload
            return state
        },
        removeRole(state, action) {
            state.splice(action.payload, 1)
            return state
            // return []
        }
    }
})

export default roleSlice.reducer;
export const { newRole, fetchRole, existingRole, removeRole } = roleSlice.actions;